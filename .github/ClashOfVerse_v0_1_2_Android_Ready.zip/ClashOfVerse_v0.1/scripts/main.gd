extends Node3D
class_name ClashOfVerseMain

const GRID_SIZE := 18
const CELL_SIZE := 2.0
const SAVE_PATH := "user://village_save.json"

var camera: Camera3D
var camera_target := Vector3.ZERO
var ui_layer: CanvasLayer
var status_label: Label
var resource_label: Label
var build_button: Button
var save_button: Button
var cancel_button: Button

var buildings: Array[Dictionary] = []
var build_mode := false
var selected_type := "Cottage"
var gold := 500
var elixir := 500
var camera_dragging := false
var last_pointer := Vector2.ZERO
var mouse_press_position := Vector2.ZERO
var mouse_moved := false
var touch_points: Dictionary = {}
var last_pinch_distance := 0.0

func _ready() -> void:
	_create_world()
	_create_ui()
	_load_game()
	_refresh_ui()

func _create_world() -> void:
	var world_env := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.48, 0.72, 0.94)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.82, 0.87, 0.95)
	env.ambient_light_energy = 0.8
	world_env.environment = env
	add_child(world_env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -35, 0)
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	add_child(sun)

	camera = Camera3D.new()
	camera.position = Vector3(22, 25, 22)
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 31.0
	add_child(camera)
	camera.look_at(camera_target, Vector3.UP)
	camera.current = true

	var ground := MeshInstance3D.new()
	var ground_mesh := PlaneMesh.new()
	ground_mesh.size = Vector2(GRID_SIZE * CELL_SIZE, GRID_SIZE * CELL_SIZE)
	ground.mesh = ground_mesh
	var ground_mat := StandardMaterial3D.new()
	ground_mat.albedo_color = Color(0.34, 0.62, 0.28)
	ground_mat.roughness = 1.0
	ground.material_override = ground_mat
	ground.position.y = -0.08
	add_child(ground)

	_create_grid()
	_create_decor()

func _create_grid() -> void:
	var grid_root := Node3D.new()
	grid_root.name = "BuildGrid"
	add_child(grid_root)
	var line_mat := StandardMaterial3D.new()
	line_mat.albedo_color = Color(0.18, 0.38, 0.16, 0.45)
	line_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	for i in range(GRID_SIZE + 1):
		var offset := -GRID_SIZE * CELL_SIZE / 2.0 + float(i) * CELL_SIZE
		_add_grid_line(grid_root, Vector3(offset, 0.012, -GRID_SIZE * CELL_SIZE / 2.0),
			Vector3(offset, 0.012, GRID_SIZE * CELL_SIZE / 2.0), line_mat)
		_add_grid_line(grid_root, Vector3(-GRID_SIZE * CELL_SIZE / 2.0, 0.012, offset),
			Vector3(GRID_SIZE * CELL_SIZE / 2.0, 0.012, offset), line_mat)

func _add_grid_line(parent: Node3D, a: Vector3, b: Vector3, material: Material) -> void:
	var mesh_instance := MeshInstance3D.new()
	var mesh := ImmediateMesh.new()
	mesh.surface_begin(Mesh.PRIMITIVE_LINES, material)
	mesh.surface_add_vertex(a)
	mesh.surface_add_vertex(b)
	mesh.surface_end()
	mesh_instance.mesh = mesh
	parent.add_child(mesh_instance)

func _create_decor() -> void:
	# Simple low-poly trees around the village edge; all meshes are generated locally.
	for i in range(34):
		var angle := TAU * float(i) / 34.0
		var radius := 21.0 + float((i % 3) * 1.3)
		var p := Vector3(cos(angle) * radius, 0, sin(angle) * radius)
		_make_tree(p)

func _make_tree(p: Vector3) -> void:
	var trunk := MeshInstance3D.new()
	var trunk_mesh := CylinderMesh.new()
	trunk_mesh.top_radius = 0.18
	trunk_mesh.bottom_radius = 0.25
	trunk_mesh.height = 1.2
	trunk.mesh = trunk_mesh
	trunk.position = p + Vector3(0, 0.6, 0)
	var bark := StandardMaterial3D.new()
	bark.albedo_color = Color(0.32, 0.18, 0.09)
	trunk.material_override = bark
	add_child(trunk)

	var crown := MeshInstance3D.new()
	var crown_mesh := SphereMesh.new()
	crown_mesh.radius = 0.85
	crown_mesh.height = 1.5
	crown.mesh = crown_mesh
	crown.position = p + Vector3(0, 1.75, 0)
	var leaves := StandardMaterial3D.new()
	leaves.albedo_color = Color(0.12, 0.43 + randf() * 0.12, 0.18)
	crown.material_override = leaves
	add_child(crown)

func _create_ui() -> void:
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)

	var panel := PanelContainer.new()
	panel.position = Vector2(16, 14)
	panel.custom_minimum_size = Vector2(390, 82)
	ui_layer.add_child(panel)
	var top_box := VBoxContainer.new()
	panel.add_child(top_box)
	resource_label = Label.new()
	resource_label.add_theme_font_size_override("font_size", 22)
	top_box.add_child(resource_label)
	status_label = Label.new()
	status_label.text = "دهکده شما آماده است"
	status_label.add_theme_font_size_override("font_size", 16)
	top_box.add_child(status_label)

	var controls := HBoxContainer.new()
	controls.anchor_left = 0.0
	controls.anchor_top = 1.0
	controls.anchor_right = 1.0
	controls.anchor_bottom = 1.0
	controls.offset_left = 16
	controls.offset_top = -82
	controls.offset_right = -16
	controls.offset_bottom = -16
	controls.add_theme_constant_override("separation", 10)
	ui_layer.add_child(controls)

	build_button = _make_button("ساخت ساختمان", Vector2(180, 58))
	build_button.pressed.connect(_on_build_pressed)
	controls.add_child(build_button)

	save_button = _make_button("ذخیره بازی", Vector2(150, 58))
	save_button.pressed.connect(_save_game)
	controls.add_child(save_button)

	cancel_button = _make_button("لغو", Vector2(110, 58))
	cancel_button.visible = false
	cancel_button.pressed.connect(_cancel_build)
	controls.add_child(cancel_button)

func _make_button(text_value: String, min_size: Vector2) -> Button:
	var button := Button.new()
	button.text = text_value
	button.custom_minimum_size = min_size
	button.add_theme_font_size_override("font_size", 19)
	return button

func _refresh_ui() -> void:
	resource_label.text = "🪙 طلا: %d      💜 اکسیر: %d" % [gold, elixir]
	if build_mode:
		status_label.text = "حالت ساخت: روی یک خانه خالی ضربه بزنید"
	else:
		status_label.text = "برای جابه‌جایی دوربین صفحه را بکشید"
	build_button.text = "ساخت ساختمان" if not build_mode else "در حال ساخت..."
	cancel_button.visible = build_mode

func _on_build_pressed() -> void:
	build_mode = true
	selected_type = "Cottage"
	_refresh_ui()

func _cancel_build() -> void:
	build_mode = false
	_refresh_ui()

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			touch_points[event.index] = event.position
			if touch_points.size() == 1:
				last_pointer = event.position
			elif touch_points.size() == 2:
				var pts: Array = touch_points.values()
				last_pinch_distance = pts[0].distance_to(pts[1])
		else:
			touch_points.erase(event.index)
			if touch_points.is_empty():
				last_pinch_distance = 0.0
				if build_mode:
					_try_place_from_screen(event.position)
		return

	if event is InputEventScreenDrag:
		touch_points[event.index] = event.position
		if touch_points.size() == 1:
			_pan_camera(event.relative)
		elif touch_points.size() == 2:
			var pts: Array = touch_points.values()
			var distance: float = pts[0].distance_to(pts[1])
			if last_pinch_distance > 0.0:
				_zoom_camera((last_pinch_distance - distance) * 0.035)
			last_pinch_distance = distance
		return

	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				camera_dragging = true
				mouse_press_position = event.position
				last_pointer = event.position
				mouse_moved = false
			else:
				camera_dragging = false
				if build_mode and not mouse_moved and mouse_press_position.distance_to(event.position) < 12.0:
					_try_place_from_screen(event.position)
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_UP:
			_zoom_camera(-1.5)
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_zoom_camera(1.5)
		return

	if event is InputEventMouseMotion and camera_dragging:
		var delta: Vector2 = event.position - last_pointer
		last_pointer = event.position
		if delta.length() > 2.0:
			mouse_moved = true
		_pan_camera(delta)

func _pan_camera(delta: Vector2) -> void:
	var right := camera.global_transform.basis.x
	var forward := camera.global_transform.basis.z
	var movement := (-right * delta.x + forward * delta.y) * 0.035
	var pan := Vector3(movement.x, 0, movement.z)
	camera.position += pan
	camera_target += pan
	var clamped_x := clampf(camera.position.x, -25.0, 25.0)
	var clamped_z := clampf(camera.position.z, -25.0, 25.0)
	camera_target += Vector3(clamped_x - camera.position.x, 0.0, clamped_z - camera.position.z)
	camera.position.x = clamped_x
	camera.position.z = clamped_z
	camera.look_at(camera_target, Vector3.UP)

func _zoom_camera(amount: float) -> void:
	camera.size = clampf(camera.size + amount, 16.0, 48.0)

func _try_place_from_screen(screen_pos: Vector2) -> void:
	if not build_mode:
		return
	var origin := camera.project_ray_origin(screen_pos)
	var direction := camera.project_ray_normal(screen_pos)
	if absf(direction.y) < 0.001:
		return
	var distance := -origin.y / direction.y
	if distance < 0:
		return
	var hit := origin + direction * distance
	var cell := _world_to_cell(hit)
	if not _is_cell_available(cell):
		status_label.text = "این خانه قابل ساخت نیست"
		return
	if gold < 100:
		status_label.text = "طلای کافی ندارید"
		return
	gold -= 100
	var world_pos := _cell_to_world(cell)
	_create_building_visual(world_pos, "Cottage")
	buildings.append({"type": "Cottage", "x": cell.x, "z": cell.y, "level": 1})
	build_mode = false
	_refresh_ui()
	_save_game()

func _world_to_cell(pos: Vector3) -> Vector2i:
	var x := int(round(pos.x / CELL_SIZE))
	var z := int(round(pos.z / CELL_SIZE))
	return Vector2i(x, z)

func _cell_to_world(cell: Vector2i) -> Vector3:
	return Vector3(float(cell.x) * CELL_SIZE, 0, float(cell.y) * CELL_SIZE)

func _is_cell_available(cell: Vector2i) -> bool:
	var half := GRID_SIZE / 2
	if cell.x < -half or cell.x >= half or cell.y < -half or cell.y >= half:
		return false
	for building in buildings:
		if int(building.x) == cell.x and int(building.z) == cell.y:
			return false
	return true

func _create_building_visual(pos: Vector3, building_type: String) -> void:
	var root := Node3D.new()
	root.position = pos
	add_child(root)

	var base := MeshInstance3D.new()
	var base_mesh := BoxMesh.new()
	base_mesh.size = Vector3(1.65, 0.45, 1.65)
	base.mesh = base_mesh
	base.position.y = 0.25
	var base_mat := StandardMaterial3D.new()
	base_mat.albedo_color = Color(0.55, 0.38, 0.22)
	base.material_override = base_mat
	root.add_child(base)

	var body := MeshInstance3D.new()
	var body_mesh := BoxMesh.new()
	body_mesh.size = Vector3(1.25, 1.25, 1.25)
	body.mesh = body_mesh
	body.position.y = 1.0
	var body_mat := StandardMaterial3D.new()
	body_mat.albedo_color = Color(0.86, 0.55, 0.25)
	body.material_override = body_mat
	root.add_child(body)

	var roof := MeshInstance3D.new()
	var roof_mesh := PrismMesh.new()
	roof_mesh.size = Vector3(1.55, 0.8, 1.55)
	roof.mesh = roof_mesh
	roof.position.y = 2.0
	var roof_mat := StandardMaterial3D.new()
	roof_mat.albedo_color = Color(0.68, 0.16, 0.12)
	roof.material_override = roof_mat
	root.add_child(roof)

	var label := Label3D.new()
	label.text = building_type
	label.position.y = 2.8
	label.font_size = 32
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	root.add_child(label)

func _save_game() -> void:
	var data := {
		"version": 1,
		"gold": gold,
		"elixir": elixir,
		"buildings": buildings
	}
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		status_label.text = "خطا در ذخیره بازی"
		return
	file.store_string(JSON.stringify(data))
	file.close()
	_refresh_ui()
	status_label.text = "بازی با موفقیت ذخیره شد"

func _load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		# Starter Town Hall for a fresh village.
		buildings.append({"type": "Town Hall", "x": 0, "z": 0, "level": 1})
		_create_building_visual(Vector3.ZERO, "Town Hall")
		return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	gold = int(parsed.get("gold", 500))
	elixir = int(parsed.get("elixir", 500))
	buildings.clear()
	for item in parsed.get("buildings", []):
		if typeof(item) == TYPE_DICTIONARY:
			buildings.append(item)
			var pos := _cell_to_world(Vector2i(int(item.get("x", 0)), int(item.get("z", 0))))
			_create_building_visual(pos, str(item.get("type", "Cottage")))
