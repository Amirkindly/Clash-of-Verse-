extends Node3D
class_name ClashOfVerseMain

const GRID_SIZE := 18
const CELL_SIZE := 2.0
const SAVE_PATH := "user://village_save.json"

const BUILDING_DATA := {
	"Town Hall": {"cost": 0, "size": 2, "kind": "hall"},
	"Cottage": {"cost": 100, "size": 1, "kind": "house"},
	"Gold Mine": {"cost": 180, "size": 2, "kind": "mine"},
	"Elixir Collector": {"cost": 180, "size": 2, "kind": "elixir"},
	"Barracks": {"cost": 250, "size": 2, "kind": "barracks"},
	"Gold Storage": {"cost": 220, "size": 2, "kind": "storage"},
	"Archer Tower": {"cost": 300, "size": 1, "kind": "tower"},
	"Builder Hut": {"cost": 150, "size": 1, "kind": "builder"}
}

var camera: Camera3D
var camera_target := Vector3.ZERO
var ui_layer: CanvasLayer
var resource_label: Label
var status_label: Label
var build_panel: PanelContainer
var build_button: Button
var save_button: Button
var cancel_button: Button
var rotate_button: Button
var upgrade_button: Button
var move_button: Button

var buildings: Array[Dictionary] = []
var building_nodes: Array[Node3D] = []
var build_mode := false
var move_mode := false
var selected_type := "Cottage"
var selected_index := -1
var rotation_step := 0
var gold := 500
var elixir := 500

var touch_start := Vector2.ZERO
var touch_last := Vector2.ZERO
var touch_dragged := false
var active_touch := -1
var pinch_distance := 0.0
var mouse_down := false
var mouse_start := Vector2.ZERO
var mouse_last := Vector2.ZERO
var mouse_dragged := false

var preview_root: Node3D
var preview_valid := false
var preview_cell := Vector2i.ZERO

func _ready() -> void:
	_create_world()
	_create_ui()
	_load_game()
	_rebuild_buildings()
	_create_preview()
	_refresh_ui()

func _create_world() -> void:
	var world_env := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.40, 0.66, 0.86)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.88, 0.93, 1.0)
	env.ambient_light_energy = 1.05
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world_env.environment = env
	add_child(world_env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -32, 0)
	sun.light_energy = 1.45
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 90.0
	add_child(sun)

	camera = Camera3D.new()
	camera.position = Vector3(22, 25, 22)
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 31.0
	camera.fov = 50.0
	add_child(camera)
	camera.look_at(camera_target, Vector3.UP)
	camera.current = true

	# Raised island foundation and grass surface.
	var island := MeshInstance3D.new()
	var island_mesh := BoxMesh.new()
	island_mesh.size = Vector3(GRID_SIZE * CELL_SIZE + 1.2, 0.65, GRID_SIZE * CELL_SIZE + 1.2)
	island.mesh = island_mesh
	island.position.y = -0.43
	var island_mat := StandardMaterial3D.new()
	island_mat.albedo_color = Color(0.35, 0.24, 0.15)
	island_mat.roughness = 1.0
	island.material_override = island_mat
	add_child(island)

	var ground := MeshInstance3D.new()
	var ground_mesh := PlaneMesh.new()
	ground_mesh.size = Vector2(GRID_SIZE * CELL_SIZE, GRID_SIZE * CELL_SIZE)
	ground.mesh = ground_mesh
	var grass := StandardMaterial3D.new()
	grass.albedo_color = Color(0.36, 0.72, 0.28)
	grass.roughness = 1.0
	ground.material_override = grass
	ground.position.y = -0.08
	add_child(ground)

	_create_island_details()
	_create_grid()
	_create_decor()


func _create_island_details() -> void:
	# Layered warm-stone foundation gives the floating island more depth.
	var lower := MeshInstance3D.new()
	var lower_mesh := BoxMesh.new()
	lower_mesh.size = Vector3(GRID_SIZE * CELL_SIZE + 1.55, 0.42, GRID_SIZE * CELL_SIZE + 1.55)
	lower.mesh = lower_mesh
	lower.position.y = -0.86
	var lower_mat := StandardMaterial3D.new()
	lower_mat.albedo_color = Color(0.34, 0.22, 0.14)
	lower_mat.roughness = 1.0
	lower.material_override = lower_mat
	add_child(lower)

	var rim := MeshInstance3D.new()
	var rim_mesh := BoxMesh.new()
	rim_mesh.size = Vector3(GRID_SIZE * CELL_SIZE + 1.28, 0.18, GRID_SIZE * CELL_SIZE + 1.28)
	rim.mesh = rim_mesh
	rim.position.y = -0.51
	var rim_mat := StandardMaterial3D.new()
	rim_mat.albedo_color = Color(0.72, 0.57, 0.30)
	rim_mat.roughness = 1.0
	rim.material_override = rim_mat
	add_child(rim)

	# Small rock clusters along the island sides break up the square silhouette.
	for i in range(32):
		var angle := TAU * float(i) / 32.0
		var radius := 18.35 + float(i % 3) * 0.24
		var rock := MeshInstance3D.new()
		var rock_mesh := SphereMesh.new()
		rock_mesh.radius = 0.48 + float(i % 3) * 0.10
		rock_mesh.height = 0.62 + float(i % 2) * 0.16
		rock.mesh = rock_mesh
		rock.position = Vector3(cos(angle) * radius, -0.73, sin(angle) * radius)
		rock.scale = Vector3(1.25, 0.82, 0.9)
		var rock_mat := StandardMaterial3D.new()
		rock_mat.albedo_color = [Color(0.43, 0.34, 0.27), Color(0.52, 0.41, 0.31), Color(0.62, 0.49, 0.35)][i % 3]
		rock_mat.roughness = 1.0
		rock.material_override = rock_mat
		add_child(rock)

	# A few bright crystal accents make the island feel magical.
	for i in range(7):
		var angle := TAU * float(i) / 7.0 + 0.3
		var crystal := MeshInstance3D.new()
		var crystal_mesh := PrismMesh.new()
		crystal_mesh.size = Vector3(0.42, 0.9, 0.42)
		crystal.mesh = crystal_mesh
		crystal.position = Vector3(cos(angle) * 17.7, 0.36, sin(angle) * 17.7)
		crystal.rotation_degrees = Vector3(0, float(i) * 31.0, 8.0)
		var crystal_mat := StandardMaterial3D.new()
		crystal_mat.albedo_color = Color(0.28, 0.82, 0.94)
		crystal_mat.metallic = 0.18
		crystal_mat.roughness = 0.28
		crystal.material_override = crystal_mat
		add_child(crystal)

func _create_grid() -> void:
	var grid_root := Node3D.new()
	grid_root.name = "BuildGrid"
	add_child(grid_root)
	var line_mat := StandardMaterial3D.new()
	line_mat.albedo_color = Color(0.22, 0.48, 0.19, 0.30)
	line_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	for i in range(GRID_SIZE + 1):
		var offset := -GRID_SIZE * CELL_SIZE / 2.0 + float(i) * CELL_SIZE
		_add_grid_line(grid_root, Vector3(offset, 0.012, -GRID_SIZE * CELL_SIZE / 2.0),
			Vector3(offset, 0.012, GRID_SIZE * CELL_SIZE / 2.0), line_mat)
		_add_grid_line(grid_root, Vector3(-GRID_SIZE * CELL_SIZE / 2.0, 0.012, offset),
			Vector3(GRID_SIZE * CELL_SIZE / 2.0, 0.012, offset), line_mat)

func _add_grid_line(parent: Node3D, a: Vector3, b: Vector3, material: Material) -> void:
	var mi := MeshInstance3D.new()
	var mesh := ImmediateMesh.new()
	mesh.surface_begin(Mesh.PRIMITIVE_LINES, material)
	mesh.surface_add_vertex(a)
	mesh.surface_add_vertex(b)
	mesh.surface_end()
	mi.mesh = mesh
	parent.add_child(mi)

func _create_decor() -> void:
	for i in range(42):
		var angle := TAU * float(i) / 42.0
		var radius := 19.4 + float(i % 4) * 0.75
		_make_tree(Vector3(cos(angle) * radius, 0, sin(angle) * radius), i)
	for i in range(28):
		var x := randf_range(-16.0, 16.0)
		var z := randf_range(-16.0, 16.0)
		if absf(x) < 7.0 and absf(z) < 7.0:
			continue
		_make_flower_patch(Vector3(x, 0.015, z), i)

func _make_tree(p: Vector3, index: int) -> void:
	var tree := Node3D.new()
	tree.position = p
	add_child(tree)
	var trunk := MeshInstance3D.new()
	var trunk_mesh := CylinderMesh.new()
	trunk_mesh.top_radius = 0.13
	trunk_mesh.bottom_radius = 0.22
	trunk_mesh.height = 1.25
	trunk.mesh = trunk_mesh
	trunk.position.y = 0.62
	var bark := StandardMaterial3D.new()
	bark.albedo_color = Color(0.30, 0.16, 0.08)
	trunk.material_override = bark
	tree.add_child(trunk)
	for j in range(3):
		var crown := MeshInstance3D.new()
		var crown_mesh := SphereMesh.new()
		crown_mesh.radius = 0.68 - float(j) * 0.07
		crown_mesh.height = 1.12
		crown.mesh = crown_mesh
		crown.position = Vector3(0, 1.45 + float(j) * 0.42, 0)
		crown.scale = Vector3(1.0, 0.82, 1.0)
		var leaves := StandardMaterial3D.new()
		leaves.albedo_color = [Color(0.12, 0.55, 0.20), Color(0.18, 0.66, 0.24), Color(0.24, 0.72, 0.28)][(index + j) % 3]
		crown.material_override = leaves
		tree.add_child(crown)

func _make_flower_patch(p: Vector3, index: int) -> void:
	var colors := [Color(1.0, 0.82, 0.22), Color(1.0, 0.48, 0.55), Color(0.92, 0.92, 0.72)]
	for j in range(3):
		var flower := MeshInstance3D.new()
		var mesh := SphereMesh.new()
		mesh.radius = 0.10
		mesh.height = 0.16
		flower.mesh = mesh
		flower.position = p + Vector3(float(j - 1) * 0.22, 0.12, float((j % 2) - 0.5) * 0.22)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = colors[(index + j) % colors.size()]
		flower.material_override = mat
		add_child(flower)

func _create_ui() -> void:
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)

	var top_panel := PanelContainer.new()
	top_panel.position = Vector2(14, 12)
	top_panel.custom_minimum_size = Vector2(350, 76)
	top_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.07, 0.14, 0.20, 0.88)))
	ui_layer.add_child(top_panel)
	var top_box := VBoxContainer.new()
	top_box.add_theme_constant_override("separation", 3)
	top_panel.add_child(top_box)
	resource_label = Label.new()
	resource_label.add_theme_font_size_override("font_size", 21)
	resource_label.add_theme_color_override("font_color", Color(1.0, 0.94, 0.72))
	top_box.add_child(resource_label)
	status_label = Label.new()
	status_label.add_theme_font_size_override("font_size", 15)
	status_label.add_theme_color_override("font_color", Color(0.93, 0.97, 1.0))
	top_box.add_child(status_label)

	var bottom_panel := PanelContainer.new()
	bottom_panel.anchor_left = 0.0
	bottom_panel.anchor_top = 1.0
	bottom_panel.anchor_right = 1.0
	bottom_panel.anchor_bottom = 1.0
	bottom_panel.offset_left = 12
	bottom_panel.offset_top = -94
	bottom_panel.offset_right = -12
	bottom_panel.offset_bottom = -10
	bottom_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.06, 0.12, 0.18, 0.90)))
	ui_layer.add_child(bottom_panel)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	bottom_panel.add_child(row)

	build_button = _make_button("ساخت‌وساز", Vector2(126, 58))
	build_button.pressed.connect(_toggle_build_panel)
	row.add_child(build_button)

	save_button = _make_button("ذخیره", Vector2(92, 58))
	save_button.pressed.connect(_save_game)
	row.add_child(save_button)

	upgrade_button = _make_button("ارتقا", Vector2(92, 58))
	upgrade_button.pressed.connect(_upgrade_selected)
	upgrade_button.disabled = true
	row.add_child(upgrade_button)

	move_button = _make_button("جابه‌جایی", Vector2(112, 58))
	move_button.pressed.connect(_toggle_move_mode)
	row.add_child(move_button)

	rotate_button = _make_button("چرخش", Vector2(86, 58))
	rotate_button.pressed.connect(_rotate_building)
	rotate_button.visible = false
	row.add_child(rotate_button)

	cancel_button = _make_button("لغو", Vector2(82, 58))
	cancel_button.pressed.connect(_cancel_modes)
	cancel_button.visible = false
	row.add_child(cancel_button)

	build_panel = PanelContainer.new()
	build_panel.anchor_left = 0.0
	build_panel.anchor_top = 1.0
	build_panel.anchor_right = 1.0
	build_panel.anchor_bottom = 1.0
	build_panel.offset_left = 12
	build_panel.offset_top = -174
	build_panel.offset_right = -12
	build_panel.offset_bottom = -108
	build_panel.visible = false
	build_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.08, 0.16, 0.22, 0.94)))
	ui_layer.add_child(build_panel)

	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	build_panel.add_child(scroll)
	var choices := HBoxContainer.new()
	choices.add_theme_constant_override("separation", 8)
	scroll.add_child(choices)

	for type in ["Cottage", "Gold Mine", "Elixir Collector", "Barracks", "Gold Storage", "Archer Tower", "Builder Hut"]:
		var data: Dictionary = BUILDING_DATA[type]
		var button := _make_button(_building_title(type) + "\n" + str(data.cost) + " طلا", Vector2(142, 54))
		button.pressed.connect(_select_building.bind(type))
		choices.add_child(button)

func _panel_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.corner_radius_top_left = 10
	style.corner_radius_top_right = 10
	style.corner_radius_bottom_left = 10
	style.corner_radius_bottom_right = 10
	style.content_margin_left = 10
	style.content_margin_right = 10
	style.content_margin_top = 7
	style.content_margin_bottom = 7
	return style

func _make_button(text_value: String, min_size: Vector2) -> Button:
	var button := Button.new()
	button.text = text_value
	button.custom_minimum_size = min_size
	button.add_theme_font_size_override("font_size", 16)
	button.add_theme_color_override("font_color", Color(1, 1, 1))
	button.add_theme_stylebox_override("normal", _button_style(Color(0.16, 0.31, 0.43, 1)))
	button.add_theme_stylebox_override("hover", _button_style(Color(0.22, 0.42, 0.54, 1)))
	button.add_theme_stylebox_override("pressed", _button_style(Color(0.10, 0.24, 0.34, 1)))
	return button

func _button_style(color: Color) -> StyleBoxFlat:
	var style := _panel_style(color)
	style.corner_radius_top_left = 7
	style.corner_radius_top_right = 7
	style.corner_radius_bottom_left = 7
	style.corner_radius_bottom_right = 7
	return style

func _building_title(type: String) -> String:
	var names := {
		"Cottage": "کلبه",
		"Gold Mine": "معدن طلا",
		"Elixir Collector": "جمع‌آور اکسیر",
		"Barracks": "سربازخانه",
		"Gold Storage": "انبار طلا",
		"Archer Tower": "برج کماندار",
		"Builder Hut": "خانه سازنده"
	}
	return str(names.get(type, type))

func _refresh_ui() -> void:
	resource_label.text = "🪙 طلا: %d     💜 اکسیر: %d" % [gold, elixir]
	if build_mode:
		status_label.text = "ساخت %s: محل سبز را انتخاب کنید" % _building_title(selected_type)
	elif move_mode:
		status_label.text = "جابه‌جایی: محل جدید ساختمان را انتخاب کنید"
	elif selected_index >= 0 and selected_index < buildings.size():
		var item: Dictionary = buildings[selected_index]
		status_label.text = "%s  |  سطح %d" % [_building_title(str(item.type)), int(item.level)]
	else:
		status_label.text = "برای انتخاب ساختمان روی آن ضربه بزنید؛ برای حرکت دوربین بکشید"
	upgrade_button.disabled = selected_index < 0 or selected_index >= buildings.size()
	cancel_button.visible = build_mode or move_mode
	rotate_button.visible = build_mode
	build_button.text = "بستن ساخت" if build_panel.visible else "ساخت‌وساز"

func _toggle_build_panel() -> void:
	build_panel.visible = not build_panel.visible
	if build_panel.visible:
		_cancel_modes()
	_refresh_ui()

func _select_building(type: String) -> void:
	selected_type = type
	build_mode = true
	move_mode = false
	selected_index = -1
	rotation_step = 0
	build_panel.visible = false
	_refresh_ui()
	_update_preview()

func _cancel_modes() -> void:
	build_mode = false
	move_mode = false
	if preview_root:
		preview_root.visible = false
	_refresh_ui()

func _toggle_move_mode() -> void:
	if selected_index < 0 or selected_index >= buildings.size():
		status_label.text = "ابتدا یک ساختمان را انتخاب کنید"
		return
	move_mode = true
	build_mode = false
	build_panel.visible = false
	_refresh_ui()

func _rotate_building() -> void:
	rotation_step = (rotation_step + 1) % 4
	if preview_root:
		preview_root.rotation.y = float(rotation_step) * PI / 2.0

func _create_preview() -> void:
	preview_root = Node3D.new()
	preview_root.name = "PlacementPreview"
	add_child(preview_root)
	_build_visual(preview_root, "Cottage", true)
	preview_root.visible = false

func _update_preview() -> void:
	if not preview_root:
		return
	preview_root.visible = build_mode

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			active_touch = event.index
			touch_start = event.position
			touch_last = event.position
			touch_dragged = false
		else:
			if event.index == active_touch:
				if not touch_dragged:
					_handle_world_tap(event.position)
				active_touch = -1
		return

	if event is InputEventScreenDrag:
		if event.index == active_touch:
			if event.position.distance_to(touch_start) > 12.0:
				touch_dragged = true
				_pan_camera(event.relative)
		return

	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				mouse_down = true
				mouse_start = event.position
				mouse_last = event.position
				mouse_dragged = false
			else:
				mouse_down = false
				if not mouse_dragged:
					_handle_world_tap(event.position)
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_UP:
			_zoom_camera(-1.5)
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_zoom_camera(1.5)
		return

	if event is InputEventMouseMotion and mouse_down:
		var delta := event.position - mouse_last
		mouse_last = event.position
		if event.position.distance_to(mouse_start) > 8.0:
			mouse_dragged = true
			_pan_camera(delta)

func _handle_world_tap(screen_pos: Vector2) -> void:
	var cell := _screen_to_cell(screen_pos)
	if cell.x == 99999:
		return
	if build_mode:
		_place_building(cell)
	elif move_mode:
		_move_selected(cell)
	else:
		_select_at_cell(cell)

func _screen_to_cell(screen_pos: Vector2) -> Vector2i:
	var origin := camera.project_ray_origin(screen_pos)
	var direction := camera.project_ray_normal(screen_pos)
	if absf(direction.y) < 0.001:
		return Vector2i(99999, 99999)
	var distance := -origin.y / direction.y
	if distance < 0:
		return Vector2i(99999, 99999)
	var hit := origin + direction * distance
	return _world_to_cell(hit)

func _pan_camera(delta: Vector2) -> void:
	var right := camera.global_transform.basis.x
	var forward := camera.global_transform.basis.z
	var movement := (-right * delta.x + forward * delta.y) * 0.035
	var pan := Vector3(movement.x, 0, movement.z)
	camera.position += pan
	camera_target += pan
	camera.position.x = clampf(camera.position.x, -25.0, 25.0)
	camera.position.z = clampf(camera.position.z, -25.0, 25.0)
	camera_target.x = clampf(camera_target.x, -25.0, 25.0)
	camera_target.z = clampf(camera_target.z, -25.0, 25.0)
	camera.look_at(camera_target, Vector3.UP)

func _zoom_camera(amount: float) -> void:
	camera.size = clampf(camera.size + amount, 17.0, 48.0)

func _place_building(cell: Vector2i) -> void:
	var data: Dictionary = BUILDING_DATA[selected_type]
	var cost := int(data.cost)
	if gold < cost:
		status_label.text = "طلای کافی ندارید؛ هزینه %d طلا است" % cost
		return
	if not _is_area_available(cell, int(data.size)):
		status_label.text = "این محدوده اشغال شده یا خارج از زمین است"
		return
	gold -= cost
	buildings.append({"type": selected_type, "x": cell.x, "z": cell.y, "level": 1, "rotation": rotation_step})
	_rebuild_buildings()
	_save_game(false)
	build_mode = false
	_refresh_ui()

func _move_selected(cell: Vector2i) -> void:
	if selected_index < 0 or selected_index >= buildings.size():
		_cancel_modes()
		return
	var item: Dictionary = buildings[selected_index]
	var size := int(BUILDING_DATA.get(str(item.type), {"size": 1}).size)
	if not _is_area_available(cell, size, selected_index):
		status_label.text = "این محدوده برای جابه‌جایی مناسب نیست"
		return
	item.x = cell.x
	item.z = cell.y
	buildings[selected_index] = item
	move_mode = false
	_rebuild_buildings()
	_refresh_ui()
	_save_game(false)

func _select_at_cell(cell: Vector2i) -> void:
	selected_index = -1
	for i in range(buildings.size()):
		var item: Dictionary = buildings[i]
		var size := int(BUILDING_DATA.get(str(item.type), {"size": 1}).size)
		if cell.x >= int(item.x) and cell.x < int(item.x) + size and cell.y >= int(item.z) and cell.y < int(item.z) + size:
			selected_index = i
			break
	_refresh_ui()

func _upgrade_selected() -> void:
	if selected_index < 0 or selected_index >= buildings.size():
		return
	var item: Dictionary = buildings[selected_index]
	var level := int(item.level)
	var cost := 150 * level
	if gold < cost:
		status_label.text = "برای ارتقا به %d طلا نیاز دارید" % cost
		return
	gold -= cost
	item.level = level + 1
	buildings[selected_index] = item
	_rebuild_buildings()
	_refresh_ui()
	_save_game(false)
	status_label.text = "%s به سطح %d ارتقا یافت" % [_building_title(str(item.type)), int(item.level)]

func _world_to_cell(pos: Vector3) -> Vector2i:
	return Vector2i(int(floor(pos.x / CELL_SIZE + 0.5)), int(floor(pos.z / CELL_SIZE + 0.5)))

func _cell_to_world(cell: Vector2i) -> Vector3:
	return Vector3(float(cell.x) * CELL_SIZE, 0, float(cell.y) * CELL_SIZE)

func _is_area_available(cell: Vector2i, size: int, ignore_index: int = -1) -> bool:
	var half := GRID_SIZE / 2
	if cell.x < -half or cell.y < -half or cell.x + size > half or cell.y + size > half:
		return false
	for i in range(buildings.size()):
		if i == ignore_index:
			continue
		var other: Dictionary = buildings[i]
		var other_size := int(BUILDING_DATA.get(str(other.type), {"size": 1}).size)
		var overlap_x := cell.x < int(other.x) + other_size and cell.x + size > int(other.x)
		var overlap_z := cell.y < int(other.z) + other_size and cell.y + size > int(other.z)
		if overlap_x and overlap_z:
			return false
	return true

func _rebuild_buildings() -> void:
	for node in building_nodes:
		if is_instance_valid(node):
			node.queue_free()
	building_nodes.clear()
	for item in buildings:
		var root := Node3D.new()
		root.position = _cell_to_world(Vector2i(int(item.x), int(item.z)))
		root.rotation.y = float(item.get("rotation", 0)) * PI / 2.0
		add_child(root)
		_build_visual(root, str(item.type), false, int(item.get("level", 1)))
		building_nodes.append(root)

func _build_visual(root: Node3D, building_type: String, ghost: bool = false, level: int = 1) -> void:
	var data: Dictionary = BUILDING_DATA.get(building_type, BUILDING_DATA["Cottage"])
	var kind := str(data.kind)
	var body_color := Color(0.78, 0.48, 0.24)
	var roof_color := Color(0.68, 0.14, 0.12)
	if kind == "hall":
		body_color = Color(0.72, 0.58, 0.39)
		roof_color = Color(0.20, 0.29, 0.56)
	elif kind == "mine":
		body_color = Color(0.47, 0.37, 0.27)
		roof_color = Color(0.37, 0.30, 0.24)
	elif kind == "elixir":
		body_color = Color(0.45, 0.30, 0.68)
		roof_color = Color(0.70, 0.25, 0.85)
	elif kind == "barracks":
		body_color = Color(0.62, 0.28, 0.20)
		roof_color = Color(0.30, 0.35, 0.42)
	elif kind == "storage":
		body_color = Color(0.78, 0.61, 0.20)
		roof_color = Color(0.88, 0.72, 0.25)
	elif kind == "tower":
		body_color = Color(0.68, 0.68, 0.65)
		roof_color = Color(0.55, 0.18, 0.15)
	elif kind == "builder":
		body_color = Color(0.52, 0.40, 0.25)
		roof_color = Color(0.25, 0.48, 0.28)

	var opacity := 0.48 if ghost else 1.0
	var size := 1.55 if int(data.size) == 1 else 2.85
	_add_box(root, Vector3(size, 0.36, size), Vector3(0, 0.18, 0), Color(0.43, 0.29, 0.17), opacity)
	_add_box(root, Vector3(size * 0.78, 1.35 + float(level - 1) * 0.12, size * 0.78),
		Vector3(0, 0.98 + float(level - 1) * 0.06, 0), body_color, opacity)

	if kind == "tower":
		_add_box(root, Vector3(0.82, 2.3, 0.82), Vector3(0, 2.55, 0), body_color.lightened(0.12), opacity)
		_add_box(root, Vector3(1.18, 0.28, 1.18), Vector3(0, 3.82, 0), roof_color, opacity)
		_add_box(root, Vector3(0.20, 0.8, 0.20), Vector3(0, 4.3, 0), Color(0.32, 0.22, 0.16), opacity)
	elif kind == "mine":
		_add_box(root, Vector3(1.05, 0.75, 1.05), Vector3(0, 1.85, 0), roof_color, opacity)
		_add_box(root, Vector3(0.18, 1.1, 0.18), Vector3(0.0, 2.45, 0.0), Color(0.28, 0.19, 0.12), opacity)
		_add_sphere(root, 0.34, Vector3(0.55, 1.25, 0.55), Color(1.0, 0.72, 0.12), opacity)
	elif kind == "elixir":
		_add_cylinder(root, 0.48, 1.0, Vector3(0, 1.9, 0), Color(0.42, 0.12, 0.75), opacity)
		_add_sphere(root, 0.35, Vector3(0, 2.55, 0), Color(0.82, 0.35, 1.0), opacity)
	elif kind == "storage":
		_add_cylinder(root, 0.62, 1.55, Vector3(0, 1.95, 0), body_color, opacity)
		_add_sphere(root, 0.63, Vector3(0, 2.72, 0), roof_color, opacity)
	elif kind == "barracks":
		_add_box(root, Vector3(1.1, 0.75, 0.16), Vector3(0, 1.7, 0.65), Color(0.35, 0.22, 0.14), opacity)
		_add_box(root, Vector3(0.18, 1.0, 0.18), Vector3(0.0, 2.0, 0.78), Color(0.75, 0.68, 0.50), opacity)
	else:
		# Distinct pitched-roof silhouette built from two angled roof slabs.
		_add_box(root, Vector3(size * 0.95, 0.22, size * 0.52), Vector3(0, 1.82, size * 0.23), roof_color, opacity, -0.55)
		_add_box(root, Vector3(size * 0.95, 0.22, size * 0.52), Vector3(0, 1.82, -size * 0.23), roof_color.darkened(0.10), opacity, 0.55)

	if kind == "hall":
		_add_box(root, Vector3(0.38, 1.0, 0.38), Vector3(-0.78, 1.9, -0.78), Color(0.88, 0.75, 0.48), opacity)
		_add_box(root, Vector3(0.38, 1.0, 0.38), Vector3(0.78, 1.9, 0.78), Color(0.88, 0.75, 0.48), opacity)

	_add_building_details(root, size, body_color, roof_color, opacity, kind)

	if not ghost:
		var level_label := Label3D.new()
		level_label.text = "Lv. %d" % level
		level_label.position.y = 3.0 if kind != "tower" else 4.7
		level_label.font_size = 30
		level_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		level_label.modulate = Color(1.0, 0.96, 0.78)
		root.add_child(level_label)


func _add_building_details(root: Node3D, size: float, body_color: Color, roof_color: Color, opacity: float, kind: String) -> void:
	# Stone foundation and timber trim.
	_add_box(root, Vector3(size * 0.86, 0.12, size * 0.86), Vector3(0, 0.40, 0), Color(0.82, 0.69, 0.47), opacity)
	_add_box(root, Vector3(size * 0.82, 0.10, 0.10), Vector3(0, 1.55, size * 0.34), Color(0.35, 0.20, 0.12), opacity)

	if kind != "tower":
		# Front door, golden handle and blue glass windows.
		_add_box(root, Vector3(0.34, 0.72, 0.10), Vector3(0, 0.83, size * 0.405), Color(0.30, 0.16, 0.09), opacity)
		_add_sphere(root, 0.045, Vector3(0.11, 0.82, size * 0.47), Color(1.0, 0.78, 0.24), opacity)
		var window_color := Color(0.28, 0.72, 0.91)
		for side in [-1.0, 1.0]:
			_add_box(root, Vector3(0.25, 0.30, 0.08), Vector3(side * size * 0.25, 1.20, size * 0.405), window_color, opacity)
			_add_box(root, Vector3(0.31, 0.07, 0.12), Vector3(side * size * 0.25, 1.38, size * 0.405), Color(0.91, 0.77, 0.49), opacity)
		_add_box(root, Vector3(size * 0.88, 0.10, 0.10), Vector3(0, 1.57, -size * 0.34), Color(0.91, 0.75, 0.45), opacity)

	# Roof ridge and small bright crest.
	if kind not in ["tower", "mine", "elixir", "storage"]:
		_add_box(root, Vector3(0.12, 0.18, size * 0.78), Vector3(0, 1.98, 0), roof_color.lightened(0.22), opacity)
	if kind == "hall":
		_add_sphere(root, 0.20, Vector3(0, 2.35, 0), Color(1.0, 0.78, 0.18), opacity)
	elif kind == "mine":
		_add_box(root, Vector3(0.18, 0.75, 0.18), Vector3(-0.42, 2.0, -0.30), Color(0.72, 0.55, 0.31), opacity)
	elif kind == "elixir":
		_add_cylinder(root, 0.12, 0.48, Vector3(0.52, 1.75, 0.22), Color(0.91, 0.40, 1.0), opacity)
	elif kind == "storage":
		_add_box(root, Vector3(0.12, 0.9, 0.12), Vector3(0, 2.0, 0.62), Color(0.94, 0.80, 0.35), opacity)
	elif kind == "barracks":
		_add_box(root, Vector3(0.72, 0.12, 0.12), Vector3(0, 2.28, 0.72), Color(0.90, 0.78, 0.52), opacity)
	elif kind == "tower":
		_add_box(root, Vector3(0.34, 0.16, 0.34), Vector3(0, 4.02, 0), Color(1.0, 0.78, 0.24), opacity)

func _add_box(parent: Node3D, size: Vector3, pos: Vector3, color: Color, alpha: float = 1.0, rot_z: float = 0.0) -> void:
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	mi.rotation.z = rot_z
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(color.r, color.g, color.b, alpha)
	if alpha < 1.0:
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mi.material_override = mat
	parent.add_child(mi)

func _add_sphere(parent: Node3D, radius: float, pos: Vector3, color: Color, alpha: float = 1.0) -> void:
	var mi := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mi.mesh = mesh
	mi.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(color.r, color.g, color.b, alpha)
	if alpha < 1.0:
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mi.material_override = mat
	parent.add_child(mi)

func _add_cylinder(parent: Node3D, radius: float, height: float, pos: Vector3, color: Color, alpha: float = 1.0) -> void:
	var mi := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mi.mesh = mesh
	mi.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(color.r, color.g, color.b, alpha)
	if alpha < 1.0:
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mi.material_override = mat
	parent.add_child(mi)

func _save_game(show_message: bool = true) -> void:
	var data := {"version": 2, "gold": gold, "elixir": elixir, "buildings": buildings}
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		status_label.text = "خطا در ذخیره بازی"
		return
	file.store_string(JSON.stringify(data))
	file.close()
	if show_message:
		status_label.text = "دهکده ذخیره شد"
	_refresh_ui()

func _load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		buildings.append({"type": "Town Hall", "x": -1, "z": -1, "level": 1, "rotation": 0})
		return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	gold = int(parsed.get("gold", 500))
	elixir = int(parsed.get("elixir", 500))
	buildings.clear()
	for item in parsed.get("buildings", []):
		if typeof(item) == TYPE_DICTIONARY:
			var clean := item.duplicate(true)
			clean["type"] = str(clean.get("type", "Cottage"))
			clean["x"] = int(clean.get("x", 0))
			clean["z"] = int(clean.get("z", 0))
			clean["level"] = int(clean.get("level", 1))
			clean["rotation"] = int(clean.get("rotation", 0))
			buildings.append(clean)
